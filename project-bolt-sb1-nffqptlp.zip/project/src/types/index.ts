// Game types definition
export interface GameState {
  playerCountry: string | null;
  countries: Country[];
  resources: Resources;
  research: Research[];
  alliances: Alliance[];
  messages: string[];
  invasionInProgress: boolean;
  invasionTarget: string | null;
  invasionSuccess: boolean;
  gameStarted: boolean;
}

export interface Country {
  id: string;
  name: string;
  flag: string;
  position: {
    x: number;
    y: number;
  };
  strength: number;
  conqueredBy: string | null;
  nuked?: boolean;
}

export interface Resources {
  coins: number;
  soldiers: number;
  defense: number;
}

export interface Research {
  name: string;
  cost: number;
  type: ResearchType;
  description: string;
}

export interface Alliance {
  country1: string;
  country2: string;
}

export enum ResearchType {
  MILITARY = 'MILITARY',
  ECONOMY = 'ECONOMY',
  DEFENSE = 'DEFENSE',
  SPECIAL = 'SPECIAL',
}

export enum ActionType {
  INVADE = 'INVADE',
  ALLIANCE = 'ALLIANCE',
  RESEARCH = 'RESEARCH',
  NUKE = 'NUKE',
}