import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { initialCountries } from '../data/countries';
import { GameState, Country, Research, ActionType } from '../types';

// Initial game state
const initialState: GameState = {
  playerCountry: null,
  countries: initialCountries,
  resources: {
    coins: 5000,
    soldiers: 1000,
    defense: 2000,
  },
  research: [],
  alliances: [],
  messages: [],
  invasionInProgress: false,
  invasionTarget: null,
  invasionSuccess: false,
  gameStarted: false,
};

// Game action types
type GameAction =
  | { type: 'SELECT_COUNTRY'; payload: string }
  | { type: 'INVADE_COUNTRY'; payload: string }
  | { type: 'FORM_ALLIANCE'; payload: string }
  | { type: 'RESEARCH_TECHNOLOGY'; payload: Research }
  | { type: 'ADD_RESOURCES' }
  | { type: 'USE_NUKE'; payload: string }
  | { type: 'START_INVASION_ANIMATION'; payload: string }
  | { type: 'END_INVASION_ANIMATION'; payload: boolean }
  | { type: 'ADD_MESSAGE'; payload: string }
  | { type: 'START_GAME' };

// Game reducer
const gameReducer = (state: GameState, action: GameAction): GameState => {
  switch (action.type) {
    case 'SELECT_COUNTRY':
      return {
        ...state,
        playerCountry: action.payload,
        gameStarted: true,
      };

    case 'INVADE_COUNTRY': {
      const targetCountry = state.countries.find(
        (country) => country.id === action.payload
      );
      
      if (!targetCountry || state.playerCountry === action.payload) {
        return state;
      }
      
      // Check if the country is already conquered
      if (targetCountry.conqueredBy === state.playerCountry) {
        return {
          ...state,
          messages: [
            ...state.messages,
            `You already control ${targetCountry.name}!`,
          ],
        };
      }
      
      // Check alliances
      if (state.alliances.some(
        (alliance) => 
          (alliance.country1 === state.playerCountry && alliance.country2 === action.payload) ||
          (alliance.country2 === state.playerCountry && alliance.country1 === action.payload)
      )) {
        return {
          ...state,
          messages: [
            ...state.messages,
            `You can't invade your ally ${targetCountry.name}!`,
          ],
        };
      }
      
      // Calculate invasion cost and chance of success
      const soldiersCost = targetCountry.strength * 100;
      const defenseCost = targetCountry.strength * 200;
      const coinsCost = targetCountry.strength * 500;
      
      // Check if player has enough resources
      if (
        state.resources.soldiers < soldiersCost ||
        state.resources.defense < defenseCost ||
        state.resources.coins < coinsCost
      ) {
        return {
          ...state,
          messages: [
            ...state.messages,
            `Not enough resources to invade ${targetCountry.name}!`,
            `Required: ${soldiersCost} soldiers, ${defenseCost} defense, ${coinsCost} coins`,
          ],
        };
      }
      
      // Deduct resources
      const newResources = {
        coins: state.resources.coins - coinsCost,
        soldiers: state.resources.soldiers - soldiersCost,
        defense: state.resources.defense - defenseCost,
      };
      
      // Update countries array
      const updatedCountries = state.countries.map((country) => {
        if (country.id === action.payload) {
          return {
            ...country,
            conqueredBy: state.playerCountry,
          };
        }
        return country;
      });
      
      return {
        ...state,
        resources: newResources,
        countries: updatedCountries,
        invasionInProgress: true,
        invasionTarget: action.payload,
        messages: [
          ...state.messages,
          `Invasion of ${targetCountry.name} in progress!`,
        ],
      };
    }

    case 'FORM_ALLIANCE': {
      const targetCountry = state.countries.find(
        (country) => country.id === action.payload
      );
      
      if (!targetCountry || state.playerCountry === action.payload) {
        return state;
      }
      
      // Check if alliance already exists
      const allianceExists = state.alliances.some(
        (alliance) => 
          (alliance.country1 === state.playerCountry && alliance.country2 === action.payload) ||
          (alliance.country2 === state.playerCountry && alliance.country1 === action.payload)
      );
      
      if (allianceExists) {
        return {
          ...state,
          messages: [
            ...state.messages,
            `You already have an alliance with ${targetCountry.name}!`,
          ],
        };
      }
      
      // Form alliance
      const newAlliance = {
        country1: state.playerCountry!,
        country2: action.payload,
      };
      
      return {
        ...state,
        alliances: [...state.alliances, newAlliance],
        messages: [
          ...state.messages,
          `Alliance formed with ${targetCountry.name}!`,
        ],
      };
    }

    case 'RESEARCH_TECHNOLOGY': {
      const { name, cost, type } = action.payload;
      
      // Check if already researched
      if (state.research.some((r) => r.name === name)) {
        return {
          ...state,
          messages: [
            ...state.messages,
            `You've already researched ${name}!`,
          ],
        };
      }
      
      // Check if player has enough coins
      if (state.resources.coins < cost) {
        return {
          ...state,
          messages: [
            ...state.messages,
            `Not enough coins to research ${name}! Need ${cost} coins.`,
          ],
        };
      }
      
      // Deduct coins and add research
      return {
        ...state,
        resources: {
          ...state.resources,
          coins: state.resources.coins - cost,
        },
        research: [...state.research, action.payload],
        messages: [
          ...state.messages,
          `Successfully researched ${name}!`,
        ],
      };
    }

    case 'ADD_RESOURCES':
      return {
        ...state,
        resources: {
          ...state.resources,
          soldiers: state.resources.soldiers + 100,
          defense: state.resources.defense + 1000,
        },
      };

    case 'USE_NUKE': {
      const targetCountry = state.countries.find(
        (country) => country.id === action.payload
      );
      
      if (!targetCountry || state.playerCountry === action.payload) {
        return state;
      }
      
      // Check if nuke is researched
      if (!state.research.some((r) => r.name === 'Nuclear Technology')) {
        return {
          ...state,
          messages: [
            ...state.messages,
            `You haven't researched Nuclear Technology yet!`,
          ],
        };
      }
      
      // Check if player has enough resources
      if (
        state.resources.coins < 10000 ||
        state.resources.soldiers < 5000
      ) {
        return {
          ...state,
          messages: [
            ...state.messages,
            `Not enough resources to launch nuclear attack! Need 10,000 coins and 5,000 soldiers.`,
          ],
        };
      }
      
      // Deduct resources
      const newResources = {
        ...state.resources,
        coins: state.resources.coins - 10000,
        soldiers: state.resources.soldiers - 5000,
      };
      
      // Update countries array
      const updatedCountries = state.countries.map((country) => {
        if (country.id === action.payload) {
          return {
            ...country,
            conqueredBy: state.playerCountry,
            nuked: true,
          };
        }
        return country;
      });
      
      return {
        ...state,
        resources: newResources,
        countries: updatedCountries,
        invasionInProgress: true,
        invasionTarget: action.payload,
        invasionSuccess: true,
        messages: [
          ...state.messages,
          `Nuclear attack launched on ${targetCountry.name}!`,
        ],
      };
    }

    case 'START_INVASION_ANIMATION':
      return {
        ...state,
        invasionInProgress: true,
        invasionTarget: action.payload,
      };

    case 'END_INVASION_ANIMATION':
      return {
        ...state,
        invasionInProgress: false,
        invasionTarget: null,
        invasionSuccess: false,
      };

    case 'ADD_MESSAGE':
      return {
        ...state,
        messages: [...state.messages, action.payload],
      };

    case 'START_GAME':
      return {
        ...state,
        gameStarted: true,
      };

    default:
      return state;
  }
};

// Create context
const GameContext = createContext<{
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
}>({
  state: initialState,
  dispatch: () => null,
});

// Game provider component
export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  // Add resources every 10 seconds
  useEffect(() => {
    if (state.gameStarted) {
      const interval = setInterval(() => {
        dispatch({ type: 'ADD_RESOURCES' });
      }, 10000);

      return () => clearInterval(interval);
    }
  }, [state.gameStarted]);

  // End invasion animation after 3 seconds
  useEffect(() => {
    if (state.invasionInProgress) {
      const timeout = setTimeout(() => {
        dispatch({ type: 'END_INVASION_ANIMATION', payload: false });
      }, 3000);

      return () => clearTimeout(timeout);
    }
  }, [state.invasionInProgress]);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
};

// Custom hook to use the game context
export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};