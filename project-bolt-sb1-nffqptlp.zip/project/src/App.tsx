import React from 'react';
import { GameProvider } from './context/GameContext';
import GameContainer from './components/GameContainer';
import './index.css';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <GameProvider>
        <GameContainer />
      </GameProvider>
    </div>
  );
}

export default App;