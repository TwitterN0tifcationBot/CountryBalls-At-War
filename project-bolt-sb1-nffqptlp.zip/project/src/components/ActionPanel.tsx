import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { Sword, Handshake as HandShake, FlaskRound as Flask, Bomb } from 'lucide-react';
import { researchOptions } from '../data/countries';
import { ActionType } from '../types';

const ActionPanel: React.FC = () => {
  const { state, dispatch } = useGame();
  const [selectedAction, setSelectedAction] = useState<ActionType | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [selectedResearch, setSelectedResearch] = useState<string | null>(null);

  const handleActionSelect = (action: ActionType) => {
    setSelectedAction(action);
    setSelectedCountry(null);
    setSelectedResearch(null);
  };

  const handleCountrySelect = (countryId: string) => {
    setSelectedCountry(countryId);
  };

  const handleResearchSelect = (researchName: string) => {
    setSelectedResearch(researchName);
  };

  const executeAction = () => {
    if (!selectedAction) return;

    switch (selectedAction) {
      case ActionType.INVADE:
        if (selectedCountry) {
          dispatch({ type: 'INVADE_COUNTRY', payload: selectedCountry });
          setSelectedAction(null);
          setSelectedCountry(null);
        }
        break;
      case ActionType.ALLIANCE:
        if (selectedCountry) {
          dispatch({ type: 'FORM_ALLIANCE', payload: selectedCountry });
          setSelectedAction(null);
          setSelectedCountry(null);
        }
        break;
      case ActionType.RESEARCH:
        if (selectedResearch) {
          const research = researchOptions.find(r => r.name === selectedResearch);
          if (research) {
            dispatch({ 
              type: 'RESEARCH_TECHNOLOGY', 
              payload: {
                name: research.name,
                cost: research.cost,
                type: research.type as any,
                description: research.description
              }
            });
            setSelectedAction(null);
            setSelectedResearch(null);
          }
        }
        break;
      case ActionType.NUKE:
        if (selectedCountry) {
          dispatch({ type: 'USE_NUKE', payload: selectedCountry });
          setSelectedAction(null);
          setSelectedCountry(null);
        }
        break;
    }
  };

  const getAvailableCountries = () => {
    const countries = state.countries.filter(country => 
      country.id !== state.playerCountry
    );

    if (selectedAction === ActionType.ALLIANCE) {
      // Filter out already allied countries
      return countries.filter(country => 
        !state.alliances.some(
          alliance => 
            (alliance.country1 === state.playerCountry && alliance.country2 === country.id) ||
            (alliance.country2 === state.playerCountry && alliance.country1 === country.id)
        )
      );
    }

    if (selectedAction === ActionType.INVADE || selectedAction === ActionType.NUKE) {
      // Filter out allied countries
      return countries.filter(country => 
        !state.alliances.some(
          alliance => 
            (alliance.country1 === state.playerCountry && alliance.country2 === country.id) ||
            (alliance.country2 === state.playerCountry && alliance.country1 === country.id)
        )
      );
    }

    return countries;
  };

  const hasNukes = state.research.some(r => r.name === 'Nuclear Technology');

  return (
    <div className="bg-gray-900 rounded-lg p-4 mb-4 flex-1 overflow-y-auto">
      <h2 className="text-xl font-bold mb-2 text-yellow-500">Actions</h2>
      
      <div className="grid grid-cols-2 gap-2 mb-4">
        <button
          onClick={() => handleActionSelect(ActionType.INVADE)}
          className={`flex flex-col items-center justify-center p-2 rounded-lg transition-colors ${
            selectedAction === ActionType.INVADE 
              ? 'bg-red-800 text-white' 
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
        >
          <Sword className="w-6 h-6 mb-1" />
          <span className="text-xs">Invade</span>
        </button>
        
        <button
          onClick={() => handleActionSelect(ActionType.ALLIANCE)}
          className={`flex flex-col items-center justify-center p-2 rounded-lg transition-colors ${
            selectedAction === ActionType.ALLIANCE 
              ? 'bg-blue-800 text-white' 
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
        >
          <HandShake className="w-6 h-6 mb-1" />
          <span className="text-xs">Alliance</span>
        </button>
        
        <button
          onClick={() => handleActionSelect(ActionType.RESEARCH)}
          className={`flex flex-col items-center justify-center p-2 rounded-lg transition-colors ${
            selectedAction === ActionType.RESEARCH 
              ? 'bg-purple-800 text-white' 
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
        >
          <Flask className="w-6 h-6 mb-1" />
          <span className="text-xs">Research</span>
        </button>
        
        <button
          onClick={() => handleActionSelect(ActionType.NUKE)}
          disabled={!hasNukes}
          className={`flex flex-col items-center justify-center p-2 rounded-lg transition-colors ${
            selectedAction === ActionType.NUKE 
              ? 'bg-yellow-800 text-white' 
              : hasNukes 
                ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' 
                : 'bg-gray-800 text-gray-500 cursor-not-allowed'
          }`}
        >
          <Bomb className="w-6 h-6 mb-1" />
          <span className="text-xs">Nuke</span>
        </button>
      </div>
      
      {selectedAction && (
        <div className="mt-4">
          {(selectedAction === ActionType.INVADE || selectedAction === ActionType.ALLIANCE || selectedAction === ActionType.NUKE) && (
            <div>
              <h3 className="text-sm font-semibold mb-2 text-gray-300">Select a country:</h3>
              <div className="max-h-40 overflow-y-auto space-y-1">
                {getAvailableCountries().map(country => (
                  <button
                    key={country.id}
                    onClick={() => handleCountrySelect(country.id)}
                    className={`w-full text-left p-2 rounded text-sm ${
                      selectedCountry === country.id 
                        ? 'bg-blue-700 text-white' 
                        : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                    }`}
                  >
                    <div className="flex items-center">
                      <img 
                        src={country.flag} 
                        alt={country.name} 
                        className="w-6 h-4 mr-2 object-cover border border-gray-600" 
                      />
                      <span>{country.name}</span>
                      {country.conqueredBy && (
                        <span className="ml-auto text-xs text-red-400">Conquered</span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {selectedAction === ActionType.RESEARCH && (
            <div>
              <h3 className="text-sm font-semibold mb-2 text-gray-300">Select research:</h3>
              <div className="max-h-40 overflow-y-auto space-y-1">
                {researchOptions
                  .filter(research => !state.research.some(r => r.name === research.name))
                  .map(research => (
                    <button
                      key={research.name}
                      onClick={() => handleResearchSelect(research.name)}
                      className={`w-full text-left p-2 rounded text-sm ${
                        selectedResearch === research.name 
                          ? 'bg-purple-700 text-white' 
                          : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span>{research.name}</span>
                        <span className="text-yellow-400 text-xs">{research.cost} coins</span>
                      </div>
                      <p className="text-xs mt-1 text-gray-400">{research.description}</p>
                    </button>
                  ))}
              </div>
            </div>
          )}
          
          {(selectedCountry || selectedResearch) && (
            <button
              onClick={executeAction}
              className="mt-4 w-full py-2 bg-green-700 hover:bg-green-600 text-white rounded font-semibold transition-colors"
            >
              Execute
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default ActionPanel;