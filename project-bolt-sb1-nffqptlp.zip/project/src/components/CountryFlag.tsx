import React from 'react';
import { Country } from '../types';
import { useGame } from '../context/GameContext';

interface CountryFlagProps {
  country: Country;
  isPlayerCountry: boolean;
  isConquered: boolean;
  isAlly: boolean;
  onHover: () => void;
  onHoverEnd: () => void;
}

const CountryFlag: React.FC<CountryFlagProps> = ({
  country,
  isPlayerCountry,
  isConquered,
  isAlly,
  onHover,
  onHoverEnd,
}) => {
  const { dispatch } = useGame();
  
  const handleClick = () => {
    if (isPlayerCountry) return;
    
    dispatch({ type: 'INVADE_COUNTRY', payload: country.id });
  };
  
  const getBorderStyle = () => {
    if (isPlayerCountry) return 'border-yellow-400 border-4 animate-pulse';
    if (isConquered) return 'border-green-500 border-2';
    if (isAlly) return 'border-blue-400 border-2';
    if (country.conqueredBy) return 'border-red-500 border-2 opacity-70';
    return 'border-gray-300 border hover:border-white';
  };
  
  return (
    <div
      className={`absolute z-10 w-10 h-6 transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ${getBorderStyle()} ${
        country.nuked ? 'filter brightness-50' : ''
      }`}
      style={{
        top: `${country.position.y}%`,
        left: `${country.position.x}%`,
        boxShadow: isPlayerCountry ? '0 0 10px gold' : isConquered ? '0 0 5px green' : '',
      }}
      onClick={handleClick}
      onMouseEnter={onHover}
      onMouseLeave={onHoverEnd}
    >
      <img
        src={country.flag}
        alt={country.name}
        className="w-full h-full object-cover"
      />
      {country.nuked && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <span className="text-yellow-500 text-2xl">☢️</span>
        </div>
      )}
    </div>
  );
};

export default CountryFlag;