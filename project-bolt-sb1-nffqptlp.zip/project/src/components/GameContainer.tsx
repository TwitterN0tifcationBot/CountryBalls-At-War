import React from 'react';
import { useGame } from '../context/GameContext';
import WorldMap from './WorldMap';
import ResourcePanel from './ResourcePanel';
import ActionPanel from './ActionPanel';
import MessageLog from './MessageLog';
import CountrySelection from './CountrySelection';

const GameContainer: React.FC = () => {
  const { state } = useGame();

  return (
    <div className="flex flex-col h-screen">
      <header className="bg-gray-800 p-4 text-center">
        <h1 className="text-3xl font-bold text-yellow-500">Global Conquest</h1>
        {state.playerCountry && (
          <p className="text-lg text-gray-300">
            Your Country: {state.countries.find(c => c.id === state.playerCountry)?.name}
          </p>
        )}
      </header>

      <main className="flex flex-col md:flex-row flex-1 overflow-hidden">
        {!state.gameStarted ? (
          <CountrySelection />
        ) : (
          <>
            <div className="flex-1 relative overflow-hidden">
              <WorldMap />
            </div>
            <div className="w-full md:w-80 bg-gray-800 p-4 flex flex-col">
              <ResourcePanel />
              <ActionPanel />
              <MessageLog />
            </div>
          </>
        )}
      </main>

      <footer className="bg-gray-800 p-2 text-center text-gray-400 text-sm">
        Global Conquest Game &copy; 2025
      </footer>
    </div>
  );
};

export default GameContainer;