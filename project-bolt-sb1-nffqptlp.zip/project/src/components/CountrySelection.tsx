import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { Globe } from 'lucide-react';

const CountrySelection: React.FC = () => {
  const { state, dispatch } = useGame();
  const [searchTerm, setSearchTerm] = useState('');
  
  const handleCountrySelect = (countryId: string) => {
    dispatch({ type: 'SELECT_COUNTRY', payload: countryId });
  };
  
  const filteredCountries = state.countries.filter(country =>
    country.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex-1 flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-lg p-8 max-w-md w-full">
        <div className="text-center mb-6">
          <Globe className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white">Choose Your Nation</h2>
          <p className="text-gray-400 mt-2">
            Select a country to begin your global conquest
          </p>
        </div>
        
        <div className="mb-4">
          <input
            type="text"
            placeholder="Search countries..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-yellow-500"
          />
        </div>
        
        <div className="max-h-80 overflow-y-auto space-y-2 mt-4">
          {filteredCountries.map(country => (
            <button
              key={country.id}
              onClick={() => handleCountrySelect(country.id)}
              className="w-full flex items-center p-3 bg-gray-700 hover:bg-gray-600 rounded transition-colors"
            >
              <img 
                src={country.flag} 
                alt={country.name} 
                className="w-10 h-6 object-cover border border-gray-600 mr-3" 
              />
              <div className="text-left">
                <h3 className="text-white font-semibold">{country.name}</h3>
                <p className="text-gray-400 text-sm">Strength: {country.strength}/10</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CountrySelection;