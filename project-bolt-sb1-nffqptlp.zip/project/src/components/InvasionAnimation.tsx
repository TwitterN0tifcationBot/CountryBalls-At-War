import React, { useEffect, useState } from 'react';
import { Country } from '../types';

interface InvasionAnimationProps {
  fromCountry: Country;
  toCountry: Country;
  isNuclear?: boolean;
}

const InvasionAnimation: React.FC<InvasionAnimationProps> = ({ 
  fromCountry, 
  toCountry,
  isNuclear
}) => {
  const [progress, setProgress] = useState(0);
  
  // Animation progress
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 4;
      });
    }, 50);
    
    return () => clearInterval(interval);
  }, []);
  
  // Calculate animation path points
  const startX = fromCountry.position.x;
  const startY = fromCountry.position.y;
  const endX = toCountry.position.x;
  const endY = toCountry.position.y;
  
  // Current position based on progress
  const currentX = startX + ((endX - startX) * progress / 100);
  const currentY = startY + ((endY - startY) * progress / 100);
  
  return (
    <div className="absolute inset-0 z-20 pointer-events-none">
      {/* Line connecting countries */}
      <svg className="absolute inset-0 w-full h-full">
        <line
          x1={`${startX}%`}
          y1={`${startY}%`}
          x2={`${currentX}%`}
          y2={`${currentY}%`}
          stroke={isNuclear ? '#FFC107' : '#FF4444'}
          strokeWidth="2"
          strokeDasharray={isNuclear ? '5,5' : 'none'}
        />
      </svg>
      
      {/* Moving object */}
      <div
        className={`absolute w-5 h-5 transform -translate-x-1/2 -translate-y-1/2 rounded-full ${
          isNuclear ? 'bg-yellow-400 animate-pulse' : 'bg-red-500'
        }`}
        style={{
          left: `${currentX}%`,
          top: `${currentY}%`,
          boxShadow: isNuclear ? '0 0 10px #FFC107, 0 0 20px #FFC107' : '0 0 5px #FF4444',
        }}
      >
        {isNuclear && (
          <div className="absolute inset-0 flex items-center justify-center text-black text-xs font-bold">
            ☢️
          </div>
        )}
      </div>
      
      {/* Explosion at the end */}
      {progress === 100 && (
        <div
          className="absolute transform -translate-x-1/2 -translate-y-1/2 animate-ping"
          style={{
            left: `${endX}%`,
            top: `${endY}%`,
            width: isNuclear ? '50px' : '20px',
            height: isNuclear ? '50px' : '20px',
            borderRadius: '50%',
            backgroundColor: isNuclear ? 'rgba(255, 193, 7, 0.7)' : 'rgba(255, 68, 68, 0.7)',
            boxShadow: isNuclear ? '0 0 30px #FFC107, 0 0 60px #FFC107' : '0 0 10px #FF4444',
          }}
        ></div>
      )}
    </div>
  );
};

export default InvasionAnimation;