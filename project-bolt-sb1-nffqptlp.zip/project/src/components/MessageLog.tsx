import React, { useEffect, useRef } from 'react';
import { useGame } from '../context/GameContext';

const MessageLog: React.FC = () => {
  const { state } = useGame();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.messages]);

  return (
    <div className="bg-gray-900 rounded-lg p-4 h-48">
      <h2 className="text-xl font-bold mb-2 text-yellow-500">Message Log</h2>
      
      <div className="h-32 overflow-y-auto text-sm bg-gray-950 rounded p-2">
        {state.messages.length === 0 ? (
          <p className="text-gray-500 italic">No messages yet...</p>
        ) : (
          state.messages.map((message, index) => (
            <div key={index} className="mb-1 last:mb-0">
              <p className="text-gray-300">{message}</p>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};

export default MessageLog;