import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import CountryFlag from './CountryFlag';
import InvasionAnimation from './InvasionAnimation';

const WorldMap: React.FC = () => {
  const { state } = useGame();
  const [hoveredCountry, setHoveredCountry] = useState<string | null>(null);
  
  const getCountryInfo = (id: string) => {
    return state.countries.find(country => country.id === id);
  };
  
  const isPlayerCountry = (id: string) => {
    return id === state.playerCountry;
  };
  
  const isConquered = (id: string) => {
    const country = getCountryInfo(id);
    return country?.conqueredBy === state.playerCountry;
  };
  
  const isAlly = (id: string) => {
    return state.alliances.some(
      alliance => 
        (alliance.country1 === state.playerCountry && alliance.country2 === id) ||
        (alliance.country2 === state.playerCountry && alliance.country1 === id)
    );
  };

  return (
    <div className="relative w-full h-full bg-blue-900 overflow-hidden">
      {/* World map background */}
      <div className="absolute inset-0 bg-worldMap bg-cover bg-center opacity-30"></div>
      
      {/* Country territories */}
      {state.countries.map((country) => {
        const owner = country.conqueredBy ? 
          state.countries.find(c => c.id === country.conqueredBy) : 
          country;
        
        return (
          <div
            key={`territory-${country.id}`}
            className="absolute"
            style={{
              top: `${country.position.y - 5}%`,
              left: `${country.position.x - 5}%`,
              width: '10%',
              height: '10%',
              backgroundImage: `url(${owner?.flag})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              opacity: country.nuked ? 0.5 : 0.7,
              filter: country.nuked ? 'grayscale(100%)' : 'none',
              borderRadius: '50%',
              boxShadow: isPlayerCountry(country.id) ? 
                '0 0 20px gold' : 
                isConquered(country.id) ? 
                  '0 0 15px green' : 
                  isAlly(country.id) ?
                    '0 0 15px blue' :
                    'none',
              transition: 'all 0.3s ease',
              zIndex: 1,
            }}
          />
        );
      })}

      {/* Country flags and labels */}
      {state.countries.map((country) => (
        <CountryFlag
          key={`flag-${country.id}`}
          country={country}
          isPlayerCountry={isPlayerCountry(country.id)}
          isConquered={isConquered(country.id)}
          isAlly={isAlly(country.id)}
          onHover={() => setHoveredCountry(country.id)}
          onHoverEnd={() => setHoveredCountry(null)}
        />
      ))}
      
      {/* Country info tooltip */}
      {hoveredCountry && (
        <div 
          className="absolute z-30 bg-gray-800 p-2 rounded shadow-lg text-white text-sm"
          style={{ 
            top: getCountryInfo(hoveredCountry)?.position.y + '%', 
            left: getCountryInfo(hoveredCountry)?.position.x + '%',
            transform: 'translate(10px, 10px)'
          }}
        >
          <h3 className="font-bold">{getCountryInfo(hoveredCountry)?.name}</h3>
          <p>Strength: {getCountryInfo(hoveredCountry)?.strength}</p>
          {getCountryInfo(hoveredCountry)?.conqueredBy && (
            <p className="text-red-400">
              Conquered by: {
                state.countries.find(c => c.id === getCountryInfo(hoveredCountry)?.conqueredBy)?.name
              }
            </p>
          )}
          {isAlly(hoveredCountry) && (
            <p className="text-green-400">Allied</p>
          )}
          {getCountryInfo(hoveredCountry)?.nuked && (
            <p className="text-orange-400">Nuked</p>
          )}
        </div>
      )}
      
      {/* Invasion animation */}
      {state.invasionInProgress && state.invasionTarget && state.playerCountry && (
        <InvasionAnimation 
          fromCountry={state.countries.find(c => c.id === state.playerCountry)!}
          toCountry={state.countries.find(c => c.id === state.invasionTarget)!}
          isNuclear={state.countries.find(c => c.id === state.invasionTarget)?.nuked}
        />
      )}
    </div>
  );
};

export default WorldMap;