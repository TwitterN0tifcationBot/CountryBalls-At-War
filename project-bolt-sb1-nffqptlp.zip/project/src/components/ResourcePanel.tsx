import React, { useState, useEffect } from 'react';
import { useGame } from '../context/GameContext';
import { Coins, Users, Shield } from 'lucide-react';

const ResourcePanel: React.FC = () => {
  const { state } = useGame();
  const [animateSoldiers, setAnimateSoldiers] = useState(false);
  const [animateDefense, setAnimateDefense] = useState(false);
  const [timer, setTimer] = useState(10);
  
  // Resource update timer
  useEffect(() => {
    if (state.gameStarted) {
      const interval = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            // Trigger animation
            setAnimateSoldiers(true);
            setAnimateDefense(true);
            setTimeout(() => {
              setAnimateSoldiers(false);
              setAnimateDefense(false);
            }, 1000);
            return 10;
          }
          return prev - 1;
        });
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [state.gameStarted]);

  // Count player's conquered countries
  const conqueredCountries = state.countries.filter(
    country => country.conqueredBy === state.playerCountry
  ).length;

  return (
    <div className="bg-gray-900 rounded-lg p-4 mb-4">
      <h2 className="text-xl font-bold mb-2 text-yellow-500">Resources</h2>
      
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Coins className="w-5 h-5 text-yellow-400 mr-2" />
            <span className="text-gray-300">Coins:</span>
          </div>
          <span className="font-mono text-yellow-400 font-bold">
            {state.resources.coins.toLocaleString()}
          </span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Users className="w-5 h-5 text-blue-400 mr-2" />
            <span className="text-gray-300">Soldiers:</span>
          </div>
          <span className={`font-mono font-bold ${
            animateSoldiers ? 'text-green-400 animate-bounce' : 'text-blue-400'
          }`}>
            {state.resources.soldiers.toLocaleString()}
          </span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Shield className="w-5 h-5 text-green-400 mr-2" />
            <span className="text-gray-300">Defense:</span>
          </div>
          <span className={`font-mono font-bold ${
            animateDefense ? 'text-green-400 animate-bounce' : 'text-green-400'
          }`}>
            {state.resources.defense.toLocaleString()}
          </span>
        </div>
      </div>
      
      <div className="mt-4 flex justify-between items-center">
        <div className="text-sm text-gray-400">
          Next resource update: <span className="text-white">{timer}s</span>
        </div>
        <div className="text-sm text-gray-400">
          Territories: <span className="text-white">{conqueredCountries}</span>
        </div>
      </div>
      
      <div className="mt-3 h-1 bg-gray-700 rounded-full overflow-hidden">
        <div 
          className="h-full bg-blue-500 transition-all duration-1000 ease-linear" 
          style={{ width: `${(timer / 10) * 100}%` }}
        ></div>
      </div>
    </div>
  );
};

export default ResourcePanel;